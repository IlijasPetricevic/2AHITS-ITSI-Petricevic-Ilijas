file
Das file-Tool analysiert den Inhalt einer Datei und bestimmt deren Typ, unabhängig vom Dateinamen oder der Endung. Es nutzt dabei sogenannte Magic Numbers, also charakteristische Byte-Muster, um z. B. zu erkennen, ob eine Datei ein Textdokument, ein Binärformat, ein Bild, ein Archiv oder ein ausführbares Programm ist.

tar
tar ist ein Archivierungswerkzeug, das mehrere Dateien oder ganze Verzeichnisse zu einem einzigen Archiv zusammenfasst. Es verändert die Dateien selbst nicht, sondern speichert deren Struktur, Berechtigungen und Inhalte in einem Tarball; optional kann das Archiv mit Tools wie gzip (.tar.gz) oder bzip2 (.tar.bz2) komprimiert werden.

gzip
gzip ist ein Komprimierungswerkzeug, das einzelne Dateien mithilfe des DEFLATE-Algorithmus verkleinert. Es ersetzt die Originaldatei typischerweise durch eine komprimierte Version mit der Endung .gz und speichert dabei keine Dateistruktur wie tar, sondern ausschließlich den Inhalt einer einzelnen Datei mit hoher Kompressionseffizienz.